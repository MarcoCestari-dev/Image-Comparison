﻿
namespace ImageComparison
{
    partial class frmSixImages
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbOutput1 = new System.Windows.Forms.PictureBox();
            this.pbOutput2 = new System.Windows.Forms.PictureBox();
            this.pbOutput3 = new System.Windows.Forms.PictureBox();
            this.pbOutput4 = new System.Windows.Forms.PictureBox();
            this.pbOutput5 = new System.Windows.Forms.PictureBox();
            this.pbOutput6 = new System.Windows.Forms.PictureBox();
            this.lblOutput1 = new System.Windows.Forms.Label();
            this.lblOutput2 = new System.Windows.Forms.Label();
            this.lblOutput3 = new System.Windows.Forms.Label();
            this.lblOutput4 = new System.Windows.Forms.Label();
            this.lblOutput6 = new System.Windows.Forms.Label();
            this.lblOutput5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput6)).BeginInit();
            this.SuspendLayout();
            // 
            // pbOutput1
            // 
            this.pbOutput1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput1.Location = new System.Drawing.Point(7, 50);
            this.pbOutput1.Name = "pbOutput1";
            this.pbOutput1.Size = new System.Drawing.Size(250, 280);
            this.pbOutput1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOutput1.TabIndex = 4;
            this.pbOutput1.TabStop = false;
            this.pbOutput1.DoubleClick += new System.EventHandler(this.pbOutput1_DoubleClick);
            // 
            // pbOutput2
            // 
            this.pbOutput2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput2.Location = new System.Drawing.Point(275, 50);
            this.pbOutput2.Name = "pbOutput2";
            this.pbOutput2.Size = new System.Drawing.Size(250, 280);
            this.pbOutput2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOutput2.TabIndex = 5;
            this.pbOutput2.TabStop = false;
            this.pbOutput2.DoubleClick += new System.EventHandler(this.pbOutput2_DoubleClick);
            // 
            // pbOutput3
            // 
            this.pbOutput3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput3.Location = new System.Drawing.Point(545, 50);
            this.pbOutput3.Name = "pbOutput3";
            this.pbOutput3.Size = new System.Drawing.Size(250, 280);
            this.pbOutput3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOutput3.TabIndex = 6;
            this.pbOutput3.TabStop = false;
            this.pbOutput3.DoubleClick += new System.EventHandler(this.pbOutput3_DoubleClick);
            // 
            // pbOutput4
            // 
            this.pbOutput4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput4.Location = new System.Drawing.Point(7, 381);
            this.pbOutput4.Name = "pbOutput4";
            this.pbOutput4.Size = new System.Drawing.Size(250, 280);
            this.pbOutput4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOutput4.TabIndex = 7;
            this.pbOutput4.TabStop = false;
            this.pbOutput4.DoubleClick += new System.EventHandler(this.pbOutput4_DoubleClick);
            // 
            // pbOutput5
            // 
            this.pbOutput5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput5.Location = new System.Drawing.Point(275, 381);
            this.pbOutput5.Name = "pbOutput5";
            this.pbOutput5.Size = new System.Drawing.Size(250, 280);
            this.pbOutput5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOutput5.TabIndex = 8;
            this.pbOutput5.TabStop = false;
            this.pbOutput5.DoubleClick += new System.EventHandler(this.pbOutput5_DoubleClick);
            // 
            // pbOutput6
            // 
            this.pbOutput6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput6.Location = new System.Drawing.Point(545, 381);
            this.pbOutput6.Name = "pbOutput6";
            this.pbOutput6.Size = new System.Drawing.Size(250, 280);
            this.pbOutput6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOutput6.TabIndex = 9;
            this.pbOutput6.TabStop = false;
            this.pbOutput6.DoubleClick += new System.EventHandler(this.pbOutput6_DoubleClick);
            // 
            // lblOutput1
            // 
            this.lblOutput1.AutoSize = true;
            this.lblOutput1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lblOutput1.Location = new System.Drawing.Point(5, 20);
            this.lblOutput1.Name = "lblOutput1";
            this.lblOutput1.Size = new System.Drawing.Size(140, 13);
            this.lblOutput1.TabIndex = 10;
            this.lblOutput1.Text = "Nessuna immagine caricata.";
            // 
            // lblOutput2
            // 
            this.lblOutput2.AutoSize = true;
            this.lblOutput2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lblOutput2.Location = new System.Drawing.Point(274, 20);
            this.lblOutput2.Name = "lblOutput2";
            this.lblOutput2.Size = new System.Drawing.Size(140, 13);
            this.lblOutput2.TabIndex = 11;
            this.lblOutput2.Text = "Nessuna immagine caricata.";
            // 
            // lblOutput3
            // 
            this.lblOutput3.AutoSize = true;
            this.lblOutput3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lblOutput3.Location = new System.Drawing.Point(542, 20);
            this.lblOutput3.Name = "lblOutput3";
            this.lblOutput3.Size = new System.Drawing.Size(140, 13);
            this.lblOutput3.TabIndex = 12;
            this.lblOutput3.Text = "Nessuna immagine caricata.";
            // 
            // lblOutput4
            // 
            this.lblOutput4.AutoSize = true;
            this.lblOutput4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lblOutput4.Location = new System.Drawing.Point(5, 348);
            this.lblOutput4.Name = "lblOutput4";
            this.lblOutput4.Size = new System.Drawing.Size(140, 13);
            this.lblOutput4.TabIndex = 13;
            this.lblOutput4.Text = "Nessuna immagine caricata.";
            // 
            // lblOutput6
            // 
            this.lblOutput6.AutoSize = true;
            this.lblOutput6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lblOutput6.Location = new System.Drawing.Point(542, 348);
            this.lblOutput6.Name = "lblOutput6";
            this.lblOutput6.Size = new System.Drawing.Size(140, 13);
            this.lblOutput6.TabIndex = 14;
            this.lblOutput6.Text = "Nessuna immagine caricata.";
            // 
            // lblOutput5
            // 
            this.lblOutput5.AutoSize = true;
            this.lblOutput5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lblOutput5.Location = new System.Drawing.Point(274, 348);
            this.lblOutput5.Name = "lblOutput5";
            this.lblOutput5.Size = new System.Drawing.Size(140, 13);
            this.lblOutput5.TabIndex = 14;
            this.lblOutput5.Text = "Nessuna immagine caricata.";
            // 
            // frmSixImages
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(49)))), ((int)(((byte)(54)))));
            this.ClientSize = new System.Drawing.Size(825, 670);
            this.Controls.Add(this.lblOutput5);
            this.Controls.Add(this.lblOutput6);
            this.Controls.Add(this.lblOutput4);
            this.Controls.Add(this.lblOutput3);
            this.Controls.Add(this.lblOutput2);
            this.Controls.Add(this.lblOutput1);
            this.Controls.Add(this.pbOutput6);
            this.Controls.Add(this.pbOutput5);
            this.Controls.Add(this.pbOutput4);
            this.Controls.Add(this.pbOutput3);
            this.Controls.Add(this.pbOutput2);
            this.Controls.Add(this.pbOutput1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmSixImages";
            this.Text = "frmSixImages";
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.PictureBox pbOutput1;
        public System.Windows.Forms.PictureBox pbOutput2;
        public System.Windows.Forms.PictureBox pbOutput3;
        public System.Windows.Forms.PictureBox pbOutput4;
        public System.Windows.Forms.PictureBox pbOutput5;
        public System.Windows.Forms.PictureBox pbOutput6;
        public System.Windows.Forms.Label lblOutput1;
        public System.Windows.Forms.Label lblOutput2;
        public System.Windows.Forms.Label lblOutput3;
        public System.Windows.Forms.Label lblOutput4;
        public System.Windows.Forms.Label lblOutput6;
        public System.Windows.Forms.Label lblOutput5;
    }
}