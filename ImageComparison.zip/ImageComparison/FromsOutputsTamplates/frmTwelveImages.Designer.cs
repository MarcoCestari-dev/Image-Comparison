﻿
namespace ImageComparison
{
    partial class frmTwelveImages
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblOutput11 = new System.Windows.Forms.Label();
            this.lblOutput12 = new System.Windows.Forms.Label();
            this.lblOutput10 = new System.Windows.Forms.Label();
            this.pbOutput12 = new System.Windows.Forms.PictureBox();
            this.pbOutput11 = new System.Windows.Forms.PictureBox();
            this.pbOutput10 = new System.Windows.Forms.PictureBox();
            this.lblOutput5 = new System.Windows.Forms.Label();
            this.lblOutput6 = new System.Windows.Forms.Label();
            this.lblOutput4 = new System.Windows.Forms.Label();
            this.lblOutput3 = new System.Windows.Forms.Label();
            this.lblOutput2 = new System.Windows.Forms.Label();
            this.lblOutput1 = new System.Windows.Forms.Label();
            this.pbOutput6 = new System.Windows.Forms.PictureBox();
            this.pbOutput5 = new System.Windows.Forms.PictureBox();
            this.pbOutput4 = new System.Windows.Forms.PictureBox();
            this.pbOutput3 = new System.Windows.Forms.PictureBox();
            this.pbOutput2 = new System.Windows.Forms.PictureBox();
            this.pbOutput1 = new System.Windows.Forms.PictureBox();
            this.lblOutput8 = new System.Windows.Forms.Label();
            this.lblOutput9 = new System.Windows.Forms.Label();
            this.lblOutput7 = new System.Windows.Forms.Label();
            this.pbOutput9 = new System.Windows.Forms.PictureBox();
            this.pbOutput8 = new System.Windows.Forms.PictureBox();
            this.pbOutput7 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput7)).BeginInit();
            this.SuspendLayout();
            // 
            // lblOutput11
            // 
            this.lblOutput11.AutoSize = true;
            this.lblOutput11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lblOutput11.Location = new System.Drawing.Point(272, 1008);
            this.lblOutput11.Name = "lblOutput11";
            this.lblOutput11.Size = new System.Drawing.Size(140, 13);
            this.lblOutput11.TabIndex = 37;
            this.lblOutput11.Text = "Nessuna immagine caricata.";
            // 
            // lblOutput12
            // 
            this.lblOutput12.AutoSize = true;
            this.lblOutput12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lblOutput12.Location = new System.Drawing.Point(540, 1008);
            this.lblOutput12.Name = "lblOutput12";
            this.lblOutput12.Size = new System.Drawing.Size(140, 13);
            this.lblOutput12.TabIndex = 38;
            this.lblOutput12.Text = "Nessuna immagine caricata.";
            // 
            // lblOutput10
            // 
            this.lblOutput10.AutoSize = true;
            this.lblOutput10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lblOutput10.Location = new System.Drawing.Point(3, 1008);
            this.lblOutput10.Name = "lblOutput10";
            this.lblOutput10.Size = new System.Drawing.Size(140, 13);
            this.lblOutput10.TabIndex = 36;
            this.lblOutput10.Text = "Nessuna immagine caricata.";
            // 
            // pbOutput12
            // 
            this.pbOutput12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput12.Location = new System.Drawing.Point(543, 1044);
            this.pbOutput12.Name = "pbOutput12";
            this.pbOutput12.Size = new System.Drawing.Size(250, 280);
            this.pbOutput12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOutput12.TabIndex = 32;
            this.pbOutput12.TabStop = false;
            this.pbOutput12.DoubleClick += new System.EventHandler(this.pbOutput12_DoubleClick);
            // 
            // pbOutput11
            // 
            this.pbOutput11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput11.Location = new System.Drawing.Point(273, 1044);
            this.pbOutput11.Name = "pbOutput11";
            this.pbOutput11.Size = new System.Drawing.Size(250, 280);
            this.pbOutput11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOutput11.TabIndex = 31;
            this.pbOutput11.TabStop = false;
            this.pbOutput11.DoubleClick += new System.EventHandler(this.pbOutput11_DoubleClick);
            // 
            // pbOutput10
            // 
            this.pbOutput10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput10.Location = new System.Drawing.Point(6, 1045);
            this.pbOutput10.Name = "pbOutput10";
            this.pbOutput10.Size = new System.Drawing.Size(250, 280);
            this.pbOutput10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOutput10.TabIndex = 30;
            this.pbOutput10.TabStop = false;
            this.pbOutput10.DoubleClick += new System.EventHandler(this.pbOutput10_DoubleClick);
            // 
            // lblOutput5
            // 
            this.lblOutput5.AutoSize = true;
            this.lblOutput5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lblOutput5.Location = new System.Drawing.Point(274, 348);
            this.lblOutput5.Name = "lblOutput5";
            this.lblOutput5.Size = new System.Drawing.Size(140, 13);
            this.lblOutput5.TabIndex = 61;
            this.lblOutput5.Text = "Nessuna immagine caricata.";
            // 
            // lblOutput6
            // 
            this.lblOutput6.AutoSize = true;
            this.lblOutput6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lblOutput6.Location = new System.Drawing.Point(542, 348);
            this.lblOutput6.Name = "lblOutput6";
            this.lblOutput6.Size = new System.Drawing.Size(140, 13);
            this.lblOutput6.TabIndex = 62;
            this.lblOutput6.Text = "Nessuna immagine caricata.";
            // 
            // lblOutput4
            // 
            this.lblOutput4.AutoSize = true;
            this.lblOutput4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lblOutput4.Location = new System.Drawing.Point(5, 348);
            this.lblOutput4.Name = "lblOutput4";
            this.lblOutput4.Size = new System.Drawing.Size(140, 13);
            this.lblOutput4.TabIndex = 60;
            this.lblOutput4.Text = "Nessuna immagine caricata.";
            // 
            // lblOutput3
            // 
            this.lblOutput3.AutoSize = true;
            this.lblOutput3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lblOutput3.Location = new System.Drawing.Point(542, 20);
            this.lblOutput3.Name = "lblOutput3";
            this.lblOutput3.Size = new System.Drawing.Size(140, 13);
            this.lblOutput3.TabIndex = 59;
            this.lblOutput3.Text = "Nessuna immagine caricata.";
            // 
            // lblOutput2
            // 
            this.lblOutput2.AutoSize = true;
            this.lblOutput2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lblOutput2.Location = new System.Drawing.Point(274, 20);
            this.lblOutput2.Name = "lblOutput2";
            this.lblOutput2.Size = new System.Drawing.Size(140, 13);
            this.lblOutput2.TabIndex = 58;
            this.lblOutput2.Text = "Nessuna immagine caricata.";
            // 
            // lblOutput1
            // 
            this.lblOutput1.AutoSize = true;
            this.lblOutput1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lblOutput1.Location = new System.Drawing.Point(5, 20);
            this.lblOutput1.Name = "lblOutput1";
            this.lblOutput1.Size = new System.Drawing.Size(140, 13);
            this.lblOutput1.TabIndex = 57;
            this.lblOutput1.Text = "Nessuna immagine caricata.";
            // 
            // pbOutput6
            // 
            this.pbOutput6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput6.Location = new System.Drawing.Point(545, 381);
            this.pbOutput6.Name = "pbOutput6";
            this.pbOutput6.Size = new System.Drawing.Size(250, 280);
            this.pbOutput6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOutput6.TabIndex = 56;
            this.pbOutput6.TabStop = false;
            this.pbOutput6.DoubleClick += new System.EventHandler(this.pbOutput6_DoubleClick);
            // 
            // pbOutput5
            // 
            this.pbOutput5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput5.Location = new System.Drawing.Point(275, 381);
            this.pbOutput5.Name = "pbOutput5";
            this.pbOutput5.Size = new System.Drawing.Size(250, 280);
            this.pbOutput5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOutput5.TabIndex = 55;
            this.pbOutput5.TabStop = false;
            this.pbOutput5.DoubleClick += new System.EventHandler(this.pbOutput5_DoubleClick);
            // 
            // pbOutput4
            // 
            this.pbOutput4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput4.Location = new System.Drawing.Point(7, 381);
            this.pbOutput4.Name = "pbOutput4";
            this.pbOutput4.Size = new System.Drawing.Size(250, 280);
            this.pbOutput4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOutput4.TabIndex = 54;
            this.pbOutput4.TabStop = false;
            this.pbOutput4.DoubleClick += new System.EventHandler(this.pbOutput4_DoubleClick);
            // 
            // pbOutput3
            // 
            this.pbOutput3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput3.Location = new System.Drawing.Point(545, 50);
            this.pbOutput3.Name = "pbOutput3";
            this.pbOutput3.Size = new System.Drawing.Size(250, 280);
            this.pbOutput3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOutput3.TabIndex = 53;
            this.pbOutput3.TabStop = false;
            this.pbOutput3.DoubleClick += new System.EventHandler(this.pbOutput3_DoubleClick);
            // 
            // pbOutput2
            // 
            this.pbOutput2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput2.Location = new System.Drawing.Point(275, 50);
            this.pbOutput2.Name = "pbOutput2";
            this.pbOutput2.Size = new System.Drawing.Size(250, 280);
            this.pbOutput2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOutput2.TabIndex = 52;
            this.pbOutput2.TabStop = false;
            this.pbOutput2.DoubleClick += new System.EventHandler(this.pbOutput2_DoubleClick);
            // 
            // pbOutput1
            // 
            this.pbOutput1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput1.Location = new System.Drawing.Point(7, 50);
            this.pbOutput1.Name = "pbOutput1";
            this.pbOutput1.Size = new System.Drawing.Size(250, 280);
            this.pbOutput1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOutput1.TabIndex = 51;
            this.pbOutput1.TabStop = false;
            this.pbOutput1.DoubleClick += new System.EventHandler(this.pbOutput1_DoubleClick);
            // 
            // lblOutput8
            // 
            this.lblOutput8.AutoSize = true;
            this.lblOutput8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lblOutput8.Location = new System.Drawing.Point(274, 677);
            this.lblOutput8.Name = "lblOutput8";
            this.lblOutput8.Size = new System.Drawing.Size(140, 13);
            this.lblOutput8.TabIndex = 49;
            this.lblOutput8.Text = "Nessuna immagine caricata.";
            // 
            // lblOutput9
            // 
            this.lblOutput9.AutoSize = true;
            this.lblOutput9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lblOutput9.Location = new System.Drawing.Point(542, 677);
            this.lblOutput9.Name = "lblOutput9";
            this.lblOutput9.Size = new System.Drawing.Size(140, 13);
            this.lblOutput9.TabIndex = 50;
            this.lblOutput9.Text = "Nessuna immagine caricata.";
            // 
            // lblOutput7
            // 
            this.lblOutput7.AutoSize = true;
            this.lblOutput7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lblOutput7.Location = new System.Drawing.Point(5, 677);
            this.lblOutput7.Name = "lblOutput7";
            this.lblOutput7.Size = new System.Drawing.Size(140, 13);
            this.lblOutput7.TabIndex = 48;
            this.lblOutput7.Text = "Nessuna immagine caricata.";
            // 
            // pbOutput9
            // 
            this.pbOutput9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput9.Location = new System.Drawing.Point(545, 711);
            this.pbOutput9.Name = "pbOutput9";
            this.pbOutput9.Size = new System.Drawing.Size(250, 280);
            this.pbOutput9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOutput9.TabIndex = 47;
            this.pbOutput9.TabStop = false;
            this.pbOutput9.DoubleClick += new System.EventHandler(this.pbOutput9_DoubleClick);
            // 
            // pbOutput8
            // 
            this.pbOutput8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput8.Location = new System.Drawing.Point(275, 711);
            this.pbOutput8.Name = "pbOutput8";
            this.pbOutput8.Size = new System.Drawing.Size(250, 280);
            this.pbOutput8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOutput8.TabIndex = 46;
            this.pbOutput8.TabStop = false;
            this.pbOutput8.DoubleClick += new System.EventHandler(this.pbOutput8_DoubleClick);
            // 
            // pbOutput7
            // 
            this.pbOutput7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput7.Location = new System.Drawing.Point(7, 711);
            this.pbOutput7.Name = "pbOutput7";
            this.pbOutput7.Size = new System.Drawing.Size(250, 280);
            this.pbOutput7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOutput7.TabIndex = 45;
            this.pbOutput7.TabStop = false;
            this.pbOutput7.DoubleClick += new System.EventHandler(this.pbOutput7_DoubleClick);
            // 
            // frmTwelveImages
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(49)))), ((int)(((byte)(54)))));
            this.ClientSize = new System.Drawing.Size(825, 1340);
            this.Controls.Add(this.lblOutput5);
            this.Controls.Add(this.lblOutput6);
            this.Controls.Add(this.lblOutput4);
            this.Controls.Add(this.lblOutput3);
            this.Controls.Add(this.lblOutput2);
            this.Controls.Add(this.lblOutput1);
            this.Controls.Add(this.pbOutput6);
            this.Controls.Add(this.pbOutput5);
            this.Controls.Add(this.pbOutput4);
            this.Controls.Add(this.pbOutput3);
            this.Controls.Add(this.pbOutput2);
            this.Controls.Add(this.pbOutput1);
            this.Controls.Add(this.lblOutput8);
            this.Controls.Add(this.lblOutput9);
            this.Controls.Add(this.lblOutput7);
            this.Controls.Add(this.pbOutput9);
            this.Controls.Add(this.pbOutput8);
            this.Controls.Add(this.pbOutput7);
            this.Controls.Add(this.lblOutput11);
            this.Controls.Add(this.lblOutput12);
            this.Controls.Add(this.lblOutput10);
            this.Controls.Add(this.pbOutput12);
            this.Controls.Add(this.pbOutput11);
            this.Controls.Add(this.pbOutput10);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmTwelveImages";
            this.Text = "frmTwelveImages";
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.Label lblOutput11;
        public System.Windows.Forms.Label lblOutput12;
        public System.Windows.Forms.Label lblOutput10;
        public System.Windows.Forms.PictureBox pbOutput12;
        public System.Windows.Forms.PictureBox pbOutput11;
        public System.Windows.Forms.PictureBox pbOutput10;
        public System.Windows.Forms.Label lblOutput5;
        public System.Windows.Forms.Label lblOutput6;
        public System.Windows.Forms.Label lblOutput4;
        public System.Windows.Forms.Label lblOutput3;
        public System.Windows.Forms.Label lblOutput2;
        public System.Windows.Forms.Label lblOutput1;
        public System.Windows.Forms.PictureBox pbOutput6;
        public System.Windows.Forms.PictureBox pbOutput5;
        public System.Windows.Forms.PictureBox pbOutput4;
        public System.Windows.Forms.PictureBox pbOutput3;
        public System.Windows.Forms.PictureBox pbOutput2;
        public System.Windows.Forms.PictureBox pbOutput1;
        public System.Windows.Forms.Label lblOutput8;
        public System.Windows.Forms.Label lblOutput9;
        public System.Windows.Forms.Label lblOutput7;
        public System.Windows.Forms.PictureBox pbOutput9;
        public System.Windows.Forms.PictureBox pbOutput8;
        public System.Windows.Forms.PictureBox pbOutput7;
    }
}